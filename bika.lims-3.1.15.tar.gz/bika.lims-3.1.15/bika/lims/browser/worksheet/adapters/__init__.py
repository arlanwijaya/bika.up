# coding=utf-8
from results import ResultOutOfRangeAdapter
