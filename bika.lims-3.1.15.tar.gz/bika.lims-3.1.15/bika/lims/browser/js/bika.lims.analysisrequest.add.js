/**
 */
function AnalysisRequestAddView() {


    var that = this

    that.load = function () {

    }

}
