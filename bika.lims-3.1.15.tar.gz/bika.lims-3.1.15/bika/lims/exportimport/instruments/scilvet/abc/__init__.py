#!/usr/bin/env python
# -*- coding: utf-8 -*-

""" Scil Vet abc Plus
"""
# This instrument will use the same parser and importer as Abaxis VetScan VS2, because
# its file results are equal
